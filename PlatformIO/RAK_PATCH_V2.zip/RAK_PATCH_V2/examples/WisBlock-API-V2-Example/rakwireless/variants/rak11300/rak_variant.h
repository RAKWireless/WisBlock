#pragma once
#include <stdint.h>
#ifndef _VARIANT_RAK11300_
#define _VARIANT_RAK11300_

#endif // #define _VARIANT_RAK11300_
