// Just for consistency, for RAK11310 all definitions are in the pins_arduino.h
#include "rak_variant.h"