// Just for consistency, for RAK3112 ESP32-S3 all definitions are in the pins_arduino.h

#ifndef _VARIANT_RAK3112_
#define _VARIANT_RAK3113_
#endif